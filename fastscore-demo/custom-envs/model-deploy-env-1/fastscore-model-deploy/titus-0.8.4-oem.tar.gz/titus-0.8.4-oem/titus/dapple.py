
# Enable/disable non-standard behaviours

# Set to True to make Titus accept untagged values for union types. Avro
# requires all values (except null) of a union type to be tagged. Sometimes, the
# tag seems redundat. For example, for the type ["null","double"] the standard
# requires the value of 3.14 to be wrapped as {"double": 3.14}. The
# untagged_union_values allows untagged values when where is not ambiguity. Note
# that the option affects primitive types only.
untagged_union_values = False

