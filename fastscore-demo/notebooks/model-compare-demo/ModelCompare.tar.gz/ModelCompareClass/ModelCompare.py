import numpy as np
from scipy.special import comb

class ModelCompare(object):
	internal = []
	comparative = []
	
	def __init__(self):
		global internal 
		internal = ['moments', 'min', 'max', 'emwa']
		global comparative
		comparative = ['mse','mae']


		self.x = {key: [0.]*16 if key == 'moments' else 0. for key in internal}
		self.y = {key: [0.]*16 if key == 'moments' else 0. for key in internal}
		self.x['min'] = float('inf')
		self.x['max'] = -1*float('inf')
		self.y['min'] = float('inf')
		self.y['max'] = -1*float('inf')
		self.compare = {key: 0. for key in comparative}
		self.n = 0.

			
	def to_dict(self):
		return {"x": self.x, "y": self.y, "Comparative": self.compare, 
						"NumberofRecords": self.n}

	def update_emwa(x, emwa, n):	
		alpha = 0.05
		return alpha*x + (1-alpha)*emwa

	def update_moments(x, moments, n):
		delta = x - moments[1]
		for j in range(len(moments)-1,1,-1):
			a = sum([comb(j,k)*moments[j-k]*(-1*delta/n)**k for k in
					range(1,j-1)])
			b = ((n-1)*delta/n)**j + (n-1)*(-1*delta/n)**j
			moments[j] = moments[j] + a + b

		moments[1] = moments[1] + delta/n
		return moments

	def update_mse(x,y,mse,n):
		mse = mse + ((x - y)**2 - mse)/n
		return mse
	
	def	update_mae(x,y,mae,n):
		mae = mae + (abs(x-y) - mae)/n
		return mae


	def update_min(x,minimum,n):
		minimum = np.minimum(x, minimum)
		return minimum 

	def update_max(x,maximum,n):
		maximum =  np.maximum(x, maximum)
		return maximum

	def update(self,x,y):
		self.n = self.n + 1.

		for stat in internal:
			self.x[stat] = ModelCompare.__dict__['update_' + stat](x, self.x[stat], self.n)
			self.y[stat] = ModelCompare.__dict__['update_' + stat](y, self.y[stat], self.n)
		for stat in comparative:
			self.compare[stat] = ModelCompare.__dict__['update_' + stat](x,y,
							self.compare[stat], self.n)

